<?php

return [
    'variables' => [
        'site-accent-color',
        'site-primary-color-100',
        'site-primary-color-200',
        'site-bg-color-100',
        'site-bg-color-200',
        '--be-flat-button',
        'site-bg-color-400',
        'site-text-color-100',
        'site-text-color-200',
        'site-text-color-300',
        'site-text-color-400',
        'site-border-color-100',
        'site-border-color-200',
    ]
];