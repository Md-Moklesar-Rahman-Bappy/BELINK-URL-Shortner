<?php

namespace Common\Auth\Events;

use App\User;

class UserAvatarChanged
{
    /**
     * @var User
     */
    public $user;

    /**
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }
}
