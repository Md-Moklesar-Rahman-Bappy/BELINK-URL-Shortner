<?php

return [
    [
        'property' => 'og:title',
        'content' => '{{linkGroup.NAME}}',
    ],
    [
        'property' => 'og:description',
        'content' => '{{linkGroup.DESCRIPTION}}',
    ],
    [
        'property' => 'og:type',
        'content' => 'website',
    ],
];
